<!-- Main Footer -->
<div class="footer bg-black">
    <!-- To the right -->
    <!-- Default to the left -->
    <!--<strong>{{trans('core.copyright')}} &copy; {{ date('Y') }}
      <a href="#">
        {{ settings('site_name') }}
      </a>
    </strong>-->
</div>