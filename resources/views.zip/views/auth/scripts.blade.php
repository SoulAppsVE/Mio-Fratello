<script src="{{ asset('/js/jquery/jquery.min.js') }}"></script>
<script src="{{ asset('/js/bootstrap.min.js') }}" type="text/javascript"></script>



